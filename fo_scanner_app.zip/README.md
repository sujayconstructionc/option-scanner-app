Full F&O ATM & -1 ITM Option Scanner
------------------------------------
This package contains a Streamlit app that scans a verified list of NSE F&O stocks,
fetches option chain data from NSE, detects volume spikes and premium gainers for
ATM and -1 ITM strikes, ranks the results and provides a CSV download.

How to use:
1. Upload this folder to a GitHub repository (private or public).
2. On Streamlit Cloud (share.streamlit.io) create a New App and point to this repo.
   Main file path: app.py
3. Ensure requirements.txt exists (it does).
4. Deploy and press "Run Full F&O Scan" (start with small scan limit and delay).
